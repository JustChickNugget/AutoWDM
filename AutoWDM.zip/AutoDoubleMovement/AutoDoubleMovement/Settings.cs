﻿using System;
using System.Diagnostics;
using System.Windows.Forms;
using Microsoft.Win32;

namespace AutoDoubleMovement
{
    public partial class Settings : Form
    {
        bool runner = false;

        public static bool AddToStartup(bool autorun)
        {
            var exepath = Application.ExecutablePath;
            RegistryKey reg = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run\");
            try
            {
                if (autorun)
                {
                    reg.SetValue("AutoWDM", exepath);
                }
                else
                {
                    reg.DeleteValue("AutoWDM");
                }
                reg.Flush();
                reg.Close();
            }
            catch (Exception) { return (false); }
            return (true);
        }

        public static bool AddToStartMenu(bool choice)
        {
            var exepath = Application.ExecutablePath;
            var startmenupath = @"C:\Users\Matvey\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\AutoWDM.exe";
            try
            {
                if (choice)
                {
                    ProcessStartInfo copy = new ProcessStartInfo() { FileName = "cmd.exe", Arguments = $"/k copy \"{exepath}\" \"{startmenupath}\"", UseShellExecute = true, Verb = "runas", CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden };
                    Process.Start(copy);
                }
                else
                {
                    ProcessStartInfo delete = new ProcessStartInfo() { FileName = "cmd.exe", Arguments = $"/k del \"{startmenupath}\"", UseShellExecute = true, Verb = "runas", CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden };
                    Process.Start(delete);
                }
            }
            catch (Exception) { return (false); }
            return (true);
        }

        public Settings()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (runner)
            {
                if (checkBox1.Checked)
                {
                    AddToStartup(true);
                    AutoWDM.Properties.Values.Default.AutorunValue = checkBox1.Checked;
                }
                else
                {
                    AddToStartup(false);
                    AutoWDM.Properties.Values.Default.AutorunValue = !checkBox1.Checked;
                }
            }
        }

/*      private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (runner)
            {
                if (checkBox2.Checked)
                {
                    AddToStartMenu(true);
                    AutoWDM.Properties.Values.Default.StartmenuValue = checkBox2.Checked;
                }
                else
                {
                    AddToStartMenu(false);
                    AutoWDM.Properties.Values.Default.StartmenuValue = !checkBox2.Checked;
                }
            }
        }
*/

        private void Settings_FormClosing(object sender, FormClosingEventArgs e)
        {
            AutoWDM.Properties.Values.Default.Save();
        }

        private void Settings_Load(object sender, EventArgs e)
        {
            checkBox1.Checked = AutoWDM.Properties.Values.Default.AutorunValue;
          //checkBox2.Checked = AutoWDM.Properties.Values.Default.StartmenuValue;
            runner = true;
        }
    }
}