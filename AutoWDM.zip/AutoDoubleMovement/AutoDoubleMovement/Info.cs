﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace AutoDoubleMovement
{
    public partial class Info : Form
    {
        ProcessStartInfo youtube = new ProcessStartInfo() { FileName = "https://www.youtube.com/channel/UCxGFf-j8llmGIra91GkcM9w", UseShellExecute = true };
        ProcessStartInfo github = new ProcessStartInfo() { FileName = "https://github.com/JustChickNugget", UseShellExecute = true };

        public Info()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Process.Start(youtube);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Process.Start(github);
        }
    }
}
