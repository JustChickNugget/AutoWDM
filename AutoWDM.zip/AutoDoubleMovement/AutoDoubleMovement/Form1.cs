﻿using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows.Forms;

namespace AutoDoubleMovement
{
    public partial class Form1 : Form
    {
        // VARIABLES
        CancellationTokenSource? cts;
        CancellationToken ct;

        static OpenFileDialog ofd = new OpenFileDialog();
        static Settings Settings = new Settings();
        static Info Info = new Info();

        static string path = $@"C:\Users\{Environment.UserName}\AppData\Local\AutoWDM";
        static string file = $@"{path}\WDM_path.txt";

        // METHODS, FUNCTIONS
        public async Task WDM(CancellationToken ct)
        {
            await Task.Run(async() =>
            {
                while (true)
                {
                    ct.ThrowIfCancellationRequested();

                    string file_wdm = File.ReadAllText(file);
                    Process[] fortnite = Process.GetProcessesByName("FortniteClient-Win64-Shipping");
                    Process[] wdm = Process.GetProcessesByName("wooting-double-movement");

                    await Task.Delay(100);
                    if (fortnite.Length != 0)
                    {
                        if (wdm.Length == 0)
                        {
                            Process.Start(file_wdm);
                        }
                    }
                    else
                    {
                        if (wdm.Length != 0)
                        {
                            foreach (Process _wdm in wdm)
                            {
                                _wdm.Kill();
                            }
                        }
                    }
                }
            }, ct);
        }

        private void ShowApp(object? sender, EventArgs e)
        {
            WindowState = FormWindowState.Normal;
            ShowInTaskbar = true;
            notifyIcon1.Visible = false;
        }

        private void ShowSettings(object? sender, EventArgs e)
        {
            Settings.ShowDialog();
        }

        private void ShowInfo(object? sender, EventArgs e)
        {
            Info.ShowDialog();
        }

        private void ExitApp(object? sender, EventArgs e)
        {
            Application.Exit();
        }

        // MAIN CODE
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ofd.ShowDialog() != DialogResult.Cancel)
            {
                if (ofd.FileName.Contains(@"\wooting-double-movement\wooting-double-movement.exe"))
                {
                    textBox1.Text = ofd.FileName;
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                        if (Directory.Exists(path))
                        {
                            File.WriteAllText(file, ofd.FileName);
                        }
                    }
                    else
                    {
                        File.WriteAllText(file, ofd.FileName);
                    }
                }
                else
                {
                    MessageBox.Show("Your path doesn't contain \\wooting-double-movement\\wooting-double-movement.exe", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Settings.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Info.ShowDialog();
        }

        private async void button4_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("The path cannot be null", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (!textBox1.Text.Contains(@"\wooting-double-movement\wooting-double-movement.exe"))
            {
                MessageBox.Show(@"Your path doesn't contain \wooting-double-movement\wooting-double-movement.exe", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                cts = new CancellationTokenSource();
                ct = cts.Token;

                button1.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = true;
                try
                {
                    await Task.Run(() => WDM(ct));
                }
                catch (Exception) { }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button1.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = false;
            if (cts != null)
            {
                cts.Cancel();
            }
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            WindowState = FormWindowState.Normal;
            ShowInTaskbar = true;
            notifyIcon1.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (Directory.Exists(path))
            {
                string file_wdm = File.ReadAllText(file);
                textBox1.Text = file_wdm; 
            }
            else
            {
                Directory.CreateDirectory(path);
                File.Create(file).Close();
            }
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            notifyIcon1.ContextMenuStrip = new ContextMenuStrip();
            if (WindowState == FormWindowState.Minimized)
            {
                ShowInTaskbar = false;
                notifyIcon1.Text = "AutoWDM";
                notifyIcon1.Visible = true;
                notifyIcon1.ContextMenuStrip.Items.Add("Show App", null, ShowApp);
                notifyIcon1.ContextMenuStrip.Items.Add("Settings", null, ShowSettings);
                notifyIcon1.ContextMenuStrip.Items.Add("Info", null, ShowInfo);
                notifyIcon1.ContextMenuStrip.Items.Add("Exit", null, ExitApp);
            }
        }
    }
}